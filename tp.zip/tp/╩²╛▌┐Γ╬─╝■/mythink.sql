-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 2016-05-05 15:40:30
-- 服务器版本： 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mythink`
--

-- --------------------------------------------------------

--
-- 表的结构 `cloud_admin`
--

CREATE TABLE IF NOT EXISTS `cloud_admin` (
  `id` int(11) NOT NULL,
  `loginname` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `confusion` varchar(255) DEFAULT 'cloud',
  `password` varchar(128) DEFAULT NULL,
  `is_super` int(11) DEFAULT '0',
  `is_active` int(11) DEFAULT '1',
  `time` varchar(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_admin`
--

INSERT INTO `cloud_admin` (`id`, `loginname`, `username`, `sex`, `phone`, `confusion`, `password`, `is_super`, `is_active`, `time`) VALUES
(1, 'admin', 'Vincook Gofoto', 'man', '13631661889', 'cloud', '9f0365db477c9f7d963d116b3b865b2a', 1, 1, NULL),
(2, 'user', 'Vincook Go123', 'woman', '13631661555', 'cloud', '0889781fd27ff33096ed9123b3b4e5d6', 0, 1, NULL),
(19, '1234', '123hello', 'man', '13631221145', 'jkl', 'ba2778b5aa19721cce7a5637d4a6ea2c', 0, 1, '1462188219');

-- --------------------------------------------------------

--
-- 表的结构 `cloud_auth`
--

CREATE TABLE IF NOT EXISTS `cloud_auth` (
  `id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `group` varchar(50) DEFAULT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `function` varchar(50) DEFAULT NULL,
  `ico` varchar(50) DEFAULT NULL,
  `is_active` int(4) DEFAULT '1',
  `only_super_has` int(4) DEFAULT '0',
  `is_sidebar_menu` int(4) DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_auth`
--

INSERT INTO `cloud_auth` (`id`, `title`, `group`, `controller`, `function`, `ico`, `is_active`, `only_super_has`, `is_sidebar_menu`) VALUES
(1, 'Dashboard', 'home', 'Index', 'index', 'menu-icon fa fa-tachometer', 1, 0, 1),
(2, 'Sensor Data', 'home', 'SensorDataTable', 'index', 'menu-icon fa fa-desktop', 1, 0, 1),
(3, 'Data Plotting', 'home', 'Plotting', 'index', 'menu-icon fa fa-bar-chart', 1, 0, 1),
(4, 'Gateway Manager', 'home', 'GatewayManager', 'index', 'menu-icon fa fa-calendar', 1, 1, 1),
(5, 'Gateway User', 'home', 'GatewayUser', 'index', 'menu-icon fa fa-list-alt', 1, 0, 1),
(6, 'Platform Manager', 'home', 'PlatformManager', 'index', 'menu-icon fa fa-pencil-square-o', 1, 1, 1),
(7, 'Empty Data', 'home', 'Empty', 'index', 'menu-icon fa fa-history', 1, 1, 1),
(8, 'Logout', 'home', 'Login', 'exitLogin', 'ace-icon fa fa-power-off', 1, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `cloud_blood_pressure`
--

CREATE TABLE IF NOT EXISTS `cloud_blood_pressure` (
  `id` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `systolic_pressure` int(11) DEFAULT NULL,
  `diastolic_pressure` int(11) DEFAULT NULL,
  `time` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=824 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_blood_pressure`
--

INSERT INTO `cloud_blood_pressure` (`id`, `user`, `systolic_pressure`, `diastolic_pressure`, `time`) VALUES
(786, 't', 112, 76, 1462086037),
(787, 't', 110, 76, 1462086038),
(788, 't', 111, 76, 1462086039),
(789, 't', 111, 75, 1462086040),
(790, 't', 112, 74, 1462086041),
(791, '古云', 110, 75, 1462086219),
(792, '古云', 111, 75, 1462086221),
(793, '古云', 111, 75, 1462086222),
(794, '古云', 111, 76, 1462086223),
(795, '古云', 110, 75, 1462086224),
(796, '古云', 110, 75, 1462086225),
(797, '古云', 112, 74, 1462086226),
(798, '古云', 111, 76, 1462086227),
(799, '古云', 111, 75, 1462086228),
(800, '古云', 112, 74, 1462086229),
(801, '古云', 112, 75, 1462086230),
(802, '古云', 111, 74, 1462086231),
(803, '古云', 111, 76, 1462086232),
(804, '古云', 110, 74, 1462086233),
(805, 't', 112, 76, 1462086037),
(806, 't', 110, 76, 1462086038),
(807, 't', 111, 76, 1462086039),
(808, 't', 111, 75, 1462086040),
(809, 't', 112, 74, 1462086041),
(810, '古云', 110, 75, 1462086219),
(811, '古云', 111, 75, 1462086221),
(812, '古云', 111, 75, 1462086222),
(813, '古云', 111, 76, 1462086223),
(814, '古云', 110, 75, 1462086224),
(815, '古云', 110, 75, 1462086225),
(816, '古云', 112, 74, 1462086226),
(817, '古云', 111, 76, 1462086227),
(818, '古云', 111, 75, 1462086228),
(819, '古云', 112, 74, 1462086229),
(820, '古云', 112, 75, 1462086230),
(821, '古云', 111, 74, 1462086231),
(822, '古云', 111, 76, 1462086232),
(823, '古云', 110, 74, 1462086233);

-- --------------------------------------------------------

--
-- 表的结构 `cloud_heart`
--

CREATE TABLE IF NOT EXISTS `cloud_heart` (
  `id` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `beat` int(11) DEFAULT NULL,
  `time` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=824 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_heart`
--

INSERT INTO `cloud_heart` (`id`, `user`, `beat`, `time`) VALUES
(786, 't', 70, 1462086037),
(787, 't', 70, 1462086038),
(788, 't', 70, 1462086039),
(789, 't', 70, 1462086040),
(790, 't', 71, 1462086041),
(791, '古云', 71, 1462086219),
(792, '古云', 71, 1462086221),
(793, '古云', 70, 1462086222),
(794, '古云', 71, 1462086223),
(795, '古云', 70, 1462086224),
(796, '古云', 71, 1462086225),
(797, '古云', 71, 1462086226),
(798, '古云', 70, 1462086227),
(799, '古云', 69, 1462086228),
(800, '古云', 70, 1462086229),
(801, '古云', 70, 1462086230),
(802, '古云', 69, 1462086231),
(803, '古云', 70, 1462086232),
(804, '古云', 71, 1462086233),
(805, 't', 70, 1462086037),
(806, 't', 70, 1462086038),
(807, 't', 70, 1462086039),
(808, 't', 70, 1462086040),
(809, 't', 71, 1462086041),
(810, '古云', 71, 1462086219),
(811, '古云', 71, 1462086221),
(812, '古云', 70, 1462086222),
(813, '古云', 71, 1462086223),
(814, '古云', 70, 1462086224),
(815, '古云', 71, 1462086225),
(816, '古云', 71, 1462086226),
(817, '古云', 70, 1462086227),
(818, '古云', 69, 1462086228),
(819, '古云', 70, 1462086229),
(820, '古云', 70, 1462086230),
(821, '古云', 69, 1462086231),
(822, '古云', 70, 1462086232),
(823, '古云', 71, 1462086233);

-- --------------------------------------------------------

--
-- 表的结构 `cloud_manager`
--

CREATE TABLE IF NOT EXISTS `cloud_manager` (
  `id` int(11) NOT NULL,
  `username` varchar(10) DEFAULT NULL COMMENT '显示名称',
  `loginname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `userimg` varchar(64) DEFAULT NULL,
  `is_super` int(11) DEFAULT '0',
  `time` varchar(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_manager`
--

INSERT INTO `cloud_manager` (`id`, `username`, `loginname`, `password`, `userimg`, `is_super`, `time`) VALUES
(59, 'gateway', 'admin', 'ac9bbede048b7e3817ce2a9afdc3e721', '/userimg/2016-04-07/5706493c78909.jpg', 1, '1389750196'),
(60, 'gate2777', 'xiaoming', 'e9babc4fb727a5d1a60e97b5964ce557', '/userimg/2016-04-07/5706493498317.jpg', 0, '1389750196');

-- --------------------------------------------------------

--
-- 表的结构 `cloud_mock`
--

CREATE TABLE IF NOT EXISTS `cloud_mock` (
  `id` int(11) NOT NULL,
  `mockname` varchar(30) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_mock`
--

INSERT INTO `cloud_mock` (`id`, `mockname`, `name`) VALUES
(1, 'qax', 'qaxname'),
(14, NULL, NULL),
(15, NULL, NULL),
(16, NULL, NULL),
(17, NULL, NULL),
(18, NULL, '102'),
(19, NULL, NULL),
(20, NULL, '108'),
(21, NULL, NULL),
(22, NULL, NULL),
(23, NULL, NULL),
(24, NULL, '1080'),
(25, NULL, '[object Object]'),
(26, NULL, '16'),
(27, NULL, '13'),
(28, NULL, '12'),
(29, NULL, '23'),
(30, NULL, '19'),
(31, NULL, '22'),
(32, NULL, '18'),
(33, NULL, '14'),
(34, NULL, '12'),
(35, NULL, '15'),
(36, NULL, '14'),
(37, NULL, '13'),
(38, NULL, '16'),
(39, NULL, '13'),
(40, NULL, '21'),
(41, NULL, '11'),
(42, NULL, '24');

-- --------------------------------------------------------

--
-- 表的结构 `cloud_sleep`
--

CREATE TABLE IF NOT EXISTS `cloud_sleep` (
  `id` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `sleep_state` varchar(255) DEFAULT NULL,
  `turn_over_times` int(11) DEFAULT NULL,
  `time` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=824 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `cloud_sport`
--

CREATE TABLE IF NOT EXISTS `cloud_sport` (
  `id` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `sport_state` varchar(255) DEFAULT NULL,
  `time` int(10) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=824 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_sport`
--

INSERT INTO `cloud_sport` (`id`, `user`, `sport_state`, `time`) VALUES
(786, 't', '跑步', 1462086037),
(787, 't', '走路', 1462086038),
(788, 't', '休息', 1462086039),
(789, 't', '休息', 1462086040),
(790, 't', '休息', 1462086041),
(791, '古云', '休息', 1462086219),
(792, '古云', '跑步', 1462086221),
(793, '古云', '走路', 1462086222),
(794, '古云', '静止', 1462086223),
(795, '古云', '休息', 1462086224),
(796, '古云', '静止', 1462086225),
(797, '古云', '静止', 1462086226),
(798, '古云', '休息', 1462086227),
(799, '古云', '走路', 1462086228),
(800, '古云', '走路', 1462086229),
(801, '古云', '休息', 1462086230),
(802, '古云', '走路', 1462086231),
(803, '古云', '走路', 1462086232),
(804, '古云', '休息', 1462086233),
(805, 't', '跑步', 1462086037),
(806, 't', '走路', 1462086038),
(807, 't', '休息', 1462086039),
(808, 't', '休息', 1462086040),
(809, 't', '休息', 1462086041),
(810, '古云', '休息', 1462086219),
(811, '古云', '跑步', 1462086221),
(812, '古云', '走路', 1462086222),
(813, '古云', '静止', 1462086223),
(814, '古云', '休息', 1462086224),
(815, '古云', '静止', 1462086225),
(816, '古云', '静止', 1462086226),
(817, '古云', '休息', 1462086227),
(818, '古云', '走路', 1462086228),
(819, '古云', '走路', 1462086229),
(820, '古云', '休息', 1462086230),
(821, '古云', '走路', 1462086231),
(822, '古云', '走路', 1462086232),
(823, '古云', '休息', 1462086233);

-- --------------------------------------------------------

--
-- 表的结构 `cloud_user`
--

CREATE TABLE IF NOT EXISTS `cloud_user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `information` varchar(255) DEFAULT NULL,
  `doctor` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_user`
--

INSERT INTO `cloud_user` (`id`, `username`, `sex`, `age`, `phone`, `address`, `information`, `doctor`, `time`) VALUES
(1, '古云', '1', 25, '13631221158', '广东省珠海市', '健康', '李医生', '1462180392'),
(2, '李明', '1', 23, '13631224458', '广东省珠海市', '健康', '王医生', '1462180443');

-- --------------------------------------------------------

--
-- 表的结构 `cloud_users`
--

CREATE TABLE IF NOT EXISTS `cloud_users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `phone` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_users`
--

INSERT INTO `cloud_users` (`id`, `firstname`, `lastname`, `phone`, `email`) VALUES
(3, 'fname1', 'lname1', '(000)000-0000', 'name1@gmail.com'),
(4, 'fname2', 'lname2', '(000)000-0000', 'name2@gmail.com'),
(5, 'fname3', 'lname3', '(000)000-0000', 'name3@gmail.com'),
(7, 'fname4', 'lname4', '(000)000-0000', 'name4@gmail.com'),
(8, 'fname5', 'lname5', '(000)000-0000', 'name5@gmail.com'),
(9, 'fname6', 'lname6', '(000)000-0000', 'name6@gmail.com'),
(10, 'fname7', 'lname7', '(000)000-0000', 'name7@gmail.com'),
(11, 'fname8', 'lname8', '(000)000-0000', 'name8@gmail.com'),
(12, 'fname9', 'lname9', '(000)000-0000', 'name9@gmail.com'),
(13, 'fname10', 'lname10', '(000)000-0000', 'name10@gmail.com'),
(14, '12', '12', '12', '1212name3@gmail.com');

-- --------------------------------------------------------

--
-- 表的结构 `cloud_wechat`
--

CREATE TABLE IF NOT EXISTS `cloud_wechat` (
  `id` int(11) NOT NULL,
  `wechat_id` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cloud_wechat`
--

INSERT INTO `cloud_wechat` (`id`, `wechat_id`, `username`, `time`) VALUES
(22, 'oGX6zvz1HWlaqxdaeRKPnRq6U508', '古云', '1462200522');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cloud_admin`
--
ALTER TABLE `cloud_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_auth`
--
ALTER TABLE `cloud_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_blood_pressure`
--
ALTER TABLE `cloud_blood_pressure`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_heart`
--
ALTER TABLE `cloud_heart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_manager`
--
ALTER TABLE `cloud_manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_mock`
--
ALTER TABLE `cloud_mock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_sleep`
--
ALTER TABLE `cloud_sleep`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_sport`
--
ALTER TABLE `cloud_sport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_user`
--
ALTER TABLE `cloud_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_users`
--
ALTER TABLE `cloud_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cloud_wechat`
--
ALTER TABLE `cloud_wechat`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cloud_admin`
--
ALTER TABLE `cloud_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `cloud_auth`
--
ALTER TABLE `cloud_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `cloud_blood_pressure`
--
ALTER TABLE `cloud_blood_pressure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=824;
--
-- AUTO_INCREMENT for table `cloud_heart`
--
ALTER TABLE `cloud_heart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=824;
--
-- AUTO_INCREMENT for table `cloud_manager`
--
ALTER TABLE `cloud_manager`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `cloud_mock`
--
ALTER TABLE `cloud_mock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `cloud_sleep`
--
ALTER TABLE `cloud_sleep`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=824;
--
-- AUTO_INCREMENT for table `cloud_sport`
--
ALTER TABLE `cloud_sport`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=824;
--
-- AUTO_INCREMENT for table `cloud_user`
--
ALTER TABLE `cloud_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `cloud_users`
--
ALTER TABLE `cloud_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `cloud_wechat`
--
ALTER TABLE `cloud_wechat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
