<?php
$dbConfig = include 'Common/Conf/db_config.php';
$appConfig = array(
	// 调试页
	'SHOW_PAGE_TRACE' => false,

	// 默认模块和Action
	'MODULE_ALLOW_LIST' => array('Home'),
	'DEFAULT_MODULE' => 'Home',
	//设置session的过期时间,以及session生效的域名
	// 'SESSION_OPTIONS' => array(
	// 	 'expire' => 6000,
	// ),
	// 默认控制器
	'DEFAULT_CONTROLLER' => 'Index',

	//加盐的长度
	'SALT_LENGTH' => 6,

	//用户类型key
	'SUPER' => 'SUPER',
	'ADMIN' => 'ADMIN',
	'STORE' => 'STORE',
	'USER' => 'USER',
	'APPUSER' => 'APPUSER',
	//攻略
	'STRATEGY' => 'STRATEGY',
	//区域的类型
	'COUNTRY' => 0,
	'PROVINCE' => 1,
	'LAND' => 2,
	'DISTRICT' => 3,
	'VILLAGE' => 4,
	'TOWNS' => 5,

);
//默认跳转链接
$defaultUrl = array(

);
$loginParams = array(
	'test' => '123',
	'USERNAME' => 'USERNAME',
	'LOGINNAME' => 'LOGINNAME',
	'USER_ID' => 'USER_ID',
	'TYPE' => 'TYPE',
	'SUPERORNOT' => 'SUPERORNOT',
	'MENUS' => 'MENUS',
	'LOGID' => 'LOGID',
	'SESSIONID' => 'SESSIONID',
	'SITE_ID' => 'SITE_ID',
	'SITE_TYPE' => 'SITE_TYPE',
	'SITE_NAME' => 'SITE_NAME',
);

$storeTypeMap = array(
	'HOTEL' => 5,
	'SCENIC' => 6,
	'TRAVEL' => 4,
	'MUTI' => 7,
	'CINEMA' => 8,
);

return array_merge($dbConfig, $appConfig, $defaultUrl, $loginParams, $storeTypeMap);
