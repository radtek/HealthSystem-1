<?php
namespace Home\Service;

class LoginService extends CommonService {

// 检测输入的验证码是否正确，$code为用户输入的验证码字符串
	public function check_verify_code($verifycode, $id = '') {
		$verify = new \Think\Verify();
		return $verify->check($verifycode, $id);
	}

	public function verify($loginname, $password, $verifycode) {
		if ($this->check_verify_code($verifycode) == false) {
			$data['status'] = -1;
			$data['content'] = "验证码错误";
			return $data;
		}
		$adminModel = M('admin');
		$where['loginname'] = $loginname;

		$result = $adminModel->where($where)->find();
		if ($result != NULL && $result != false) {
			if (md5($result['confusion'] . $password) == $result['password']) {
				$data['status'] = 0;
				$data['content'] = "登录成功";

				session(C('USER_ID'), $result['id']);
			} else {
				$data['status'] = 1;
				$data['content'] = "密码错误";
			}
		} else {
			$data['status'] = 2;
			$data['content'] = "该用户不存在";
		}
		$this->formReturnData($data, $result);
		return $data;
	}

	/**
	 * 合成返回的数据，包括状态
	 * 和保存在session里面的数据
	 * @param $data
	 * @param $type
	 */
	public function formReturnData($data, $result) {
		/**
		 * 如果登录成功，需要保存值到session
		 */
		if ($data['status'] == 0) {
			session('USERNAME', $result['username']);
			session('LOGINNAME', $result['loginname']);
			session('USER_ID', $result['id']);
			session('IS_SUPER',$result['is_super']);
		}
		return $data;
	}

	/**
	 * 退出登录，暂时直接赋值为空
	 * 后期输出信息
	 */
	public function exitLogin() {
		if (session('USER_ID') == null) {
			return $this->errorResultReturn("您还未登录");
		} else {
			session('LOGINNAME', null);
			session('USERNAME', null);
			session('USER_ID', null);
			session('IS_SUPER',null);
			return $this->successResultReturn("成功退出登录");
		}
	}

}
