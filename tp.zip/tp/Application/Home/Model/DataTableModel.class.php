<?php
namespace Home\Model;
use Think\Model;

class DataTableModel extends Model {
	protected $autoCheckFields = false;

//$map['time']  = array(array('egt',start_time),array('elt',end_time),'and');

	public function emptyData($whichTable) {
		$objModel = M($whichTable);
		if ($objModel->count() == 0) {
			$data['state'] = 0;
			$data['deleteNum'] = 0;
			$data['content'] = 'It was empty before!';
			return $data;
		} else {
			$result = $objModel->where('1')->delete(); //删除所有
			if ($result) {
				$data['state'] = 1;
				$data['deleteNum'] = $result;
				$data['content'] = 'Success!';
				return $data;
			} else {
				$data['state'] = -1;
				$data['deleteNum'] = 0;
				$data['content'] = 'Failed!';
				return $data;
			}
		}
	}

	public function data($whichTable) {
		$limit = $_GET['limit'];
		$offset = $_GET['offset'];
		$objModel = M($whichTable);
		if ((isset($_GET['search']) && !empty($_GET['search']))) {
			$dbFields = $objModel->getDbFields();
			$searchWord = trim($_GET['search']);
			foreach ($dbFields as $everyField) {
				$condition[$everyField] = $searchWord;
			}
			$condition['_logic'] = 'OR';
			$total = $objModel->where($condition)->count();
			$rows = $objModel->where($condition)->limit($offset . ',' . $limit)->select();
		} else {
			$total = $objModel->count(); // 查询满足要求的总记录数
			if ($limit == 'ALL') {
				$rows = $objModel->select();
			} else {
				$rows = $objModel->limit($offset . ',' . $limit)->select();
			}

		}
		foreach ($rows as $key => $value) {
			$newRows[$key] = $value;
			$newRows[$key]['order_id'] = $key + $offset;
			$newRows[$key]['convert_time'] = date("Y-m-d H:i:s", $newRows[$key]['time']);
		}
		$result["total"] = $total;
		$result["rows"] = $newRows;
		echo json_encode($result);
	}

	public function checkExist($whichTable, $field, $value) {
		$map[$field] = $value;
		if ((M($whichTable)->where($map)->count()) > 0) {
			return 1;
		} else {
			return 0;
		}
	}

}