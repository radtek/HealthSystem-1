<?php
namespace Home\Model;
use Think\Model;

class WechatModel extends Model {
	//回复多图文类型的微信消息
	protected $autoCheckFields = false;
	public function responseNews($postObj ,$arr){
		$toUser = $postObj->FromUserName;
		$fromUser = $postObj->ToUserName;
		$template = "<xml>
					<ToUserName><![CDATA[%s]]></ToUserName>
					<FromUserName><![CDATA[%s]]></FromUserName>
					<CreateTime>%s</CreateTime>
					<MsgType><![CDATA[%s]]></MsgType>
					<ArticleCount>".count($arr)."</ArticleCount>
					<Articles>";
		foreach($arr as $k=>$v){
			$template .="<item>
					<Title><![CDATA[".$v['title']."]]></Title>
					<Description><![CDATA[".$v['description']."]]></Description>
					<PicUrl><![CDATA[".$v['picUrl']."]]></PicUrl>
					<Url><![CDATA[".$v['url']."]]></Url>
					</item>";
		}

		$template .="</Articles>
					</xml> ";
		echo sprintf($template, $toUser, $fromUser, time(), 'news');
	}

	// 回复单文本
	public function responseText($postObj,$content){
		$template = "<xml>
			<ToUserName><![CDATA[%s]]></ToUserName>
			<FromUserName><![CDATA[%s]]></FromUserName>
			<CreateTime>%s</CreateTime>
			<MsgType><![CDATA[%s]]></MsgType>
			<Content><![CDATA[%s]]></Content>
			</xml>";
		//注意模板中的中括号 不能少 也不能多
		$fromUser = $postObj->ToUserName;
		$toUser   = $postObj->FromUserName;
		$time     = time();
		$msgType  = 'text';
		echo sprintf($template, $toUser, $fromUser, $time, $msgType, $content);
	}

	//回复微信用户的关注事件
	public function responseSubscribe($postObj, $arr){
		$this->responseNews($postObj,$arr);
	}

	//回复音乐
	public function transmitMusic($postObj, $musicArray){
	        $itemTpl = "<Music>
			    <Title><![CDATA[%s]]></Title>
			    <Description><![CDATA[%s]]></Description>
			    <MusicUrl><![CDATA[%s]]></MusicUrl>
			    <HQMusicUrl><![CDATA[%s]]></HQMusicUrl>
			    </Music>";
	        $item_str = sprintf($itemTpl, $musicArray['Title'], $musicArray['Description'], $musicArray['MusicUrl'], $musicArray['HQMusicUrl']);

	        $xmlTpl = "<xml>
				<ToUserName><![CDATA[%s]]></ToUserName>
				<FromUserName><![CDATA[%s]]></FromUserName>
				<CreateTime>%s</CreateTime>
				<MsgType><![CDATA[music]]></MsgType>
				$item_str
				</xml>";

	        $result = sprintf($xmlTpl, $postObj->FromUserName, $postObj->ToUserName, time());
	        echo $result;
	}
 //    //绑定微信
	// public function bindWechatId($id)
	// {
	// 	$user = M('weixin');
	// 	$date['id'] = "$id";
	// 	$res = $user->where($date)->find();
	// 	if (!$res) {
	// 		$date['name'] = "lhw";
	// 	    $date['age'] = 22;
	// 	    $res = $user->data($date)->add();
	//         if ($res==1) {
	//         	return "绑定成功";
	//         }else{
	//         	return "绑定失败";
	//         }
	// 	}else{
	// 		return "你已绑定无需此操作";
	// 	}
	// }
	public function bandNameAndWechatId($name,$wechatId)
	{
		$wechat = M('wechat');
		$data['wechat_id'] = "$wechatId";

		$result = $wechat->where($data)->find();
		if(!$result){
			$data['username'] = "$name";
			$data['time'] = strtotime(date("Y-m-d H:i:s", time()));
			$result = $wechat->data($data)->add();
			if($result){
				return "绑定成功";
			}else{
				return "绑定失败";
			}
		}else{
			return "若要重新绑定，请先解绑";
		}

	}
	//解除绑定
	public function unbindWechatId($wechatId)
	{
		$objWechat = M('wechat');
		$data['wechat_id'] = "$wechatId";
		$result = $objWechat->where($data)->find();
		if ($result) {
		    $result = $objWechat->where($data)->delete();
	        if ($result) {
	        	return "解绑成功";
	        }else{
	        	return "解绑失败";
	        }
		}else{
			return "你没有绑定无需此操作";
		}
	}
	//返回信息
	public function myNews($id)
	{
		$user = M('weixin');
		$where['id'] = "$id";
		$res = $user->where($where)->find();
		if ($res) {
        	return "你的ID: ".$res['id']."\n名字: ".$res['name'];
        }else{
        	return "查询失败你还没绑定微信";
        }
	}
}