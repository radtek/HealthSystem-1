<?php
namespace Home\Model;
use Think\Model;

class AnalysisModel extends Model {
	protected $autoCheckFields = false;

	public function weightedAverage($table, $field, $user) {
		$objModel = M($table);
		$map['user'] = $user;
		$rows = $objModel->distinct(true)->where($map)->field($field)->select();
		$rowsAno = $objModel->where($map)->field($field)->select();
		$count = $objModel->where($map)->count();
		foreach ($rows as $key => $value) {
			$arr[$value[$field]] = 0;
		}

		foreach ($rowsAno as $key => $value) {
			$a = $value[$field];
			foreach ($arr as $key => $value) {
				if ($key == $a) {
					$arr[$key]++;
					continue;
				}
			}
		}

		$result = 0;
		foreach ($arr as $key => $value) {
			$result += $key * ($value / $count);
		}
		$result = round($result);
		// print_r($arr);
		// print_r($result);
		return $result;
	}

	public function heartEvaluate($beat) {
		$evaluate = '';
		if ($beat < 40) {
			$evaluate = '诊断:心率太低,容易出现自觉心悸、气短、头晕和乏力,严重时伴有呼吸不畅、脑闷，有时心前区有冲击感。建议:应及早进行详细检查，以便针对病因进行治疗。';
		}else if($beat >= 40 && $beat <= 60){
			$evaluate = '诊断:生理性:常见于正常人睡眠中、长期参加	体育锻炼或强体力劳动者;。
				建议:1.严重者要安装心脏起搏器来加快心率。
				2.建议马上到医院咨询检查以明确原因。';
		}else if($beat > 60 && $beat < 100){
			$evaluate = "诊断:正常。\n建议:保持愉悦的心情和良好的生活习惯。";
		}else{
			$evaluate = '诊断:生理性:情绪波动造成,儿童心率比大人快,属于正常情况;病理性:感染,发热,贫血,低氧血症,低钾血症,甲状腺功能亢进,休克,心功能不全等。建议:2.非正常情况下出现的心动过快,建议前往医院咨询检查以明确原因。';
		}
		return $evaluate;
	}

	// public function bloodPressureEvaluate($systolic,$diastolic){
	// 	$evaluate = '';
	// 	if($systolic <= 90 && $diastolic <=60){
	// 		$evaluate = '诊断:1.原发性低血压多见于体质瘦弱的老人、妇女;2.继发性低血压可见于心肌梗死，过敏，感染，肿瘤，结核等。建议:1.体质虚弱者可以通过增强体质、改善营养、加强运动等改善症状;2.患有消耗性疾病者的非生理性低血压建议前往医院做进一步检查。';
	// 	}else if($systolic < 130 && $diastolic < 85){
	// 		$evaluate = '诊断:正常。建议:调整饮食及作息规律，保持心情愉快。';
	// 	}else if($systolic < 130 && $diastolic < 85){

	// 	}
	// }

}