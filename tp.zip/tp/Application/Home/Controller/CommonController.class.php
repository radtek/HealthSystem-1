<?php
namespace Home\Controller;

use Think\Controller;

/**
 * CommonController
 */

class CommonController extends Controller {

	/**
	 * 全部Controller执行之前会执行的方法
	 * 1、抛出菜单数据
	 * 2、添加登陆验证
	 *
	 */
	public function _initialize() {
		//检测是否登录
		$this->loginOrNot();
		$currentUser = session('USERNAME');
		$this->assign('currentUser', $currentUser);
		$this->authCtrl();
		$nowSidebar['controller'] = CONTROLLER_NAME;
		$nowSidebar['function'] = ACTION_NAME;
		$this->assign('nowSidebar', $nowSidebar);
	}

	private function sidebarMenu() {
		//超级管理员
		if (session('IS_SUPER') == 1) {
			$map['is_sidebar_menu'] = 1; //侧边栏菜单
			$menu = M('auth')->where($map)->select();
			$this->assign('menu', $menu);
		} else {
			//普通管理员
			$map['is_sidebar_menu'] = 1;
			$map['only_super_has'] = 0;
			$menu = M('auth')->where($map)->select();
			$this->assign('menu', $menu);
		}

	}

	private function authCtrl() {
		$auth_menu = array();
		if (session('IS_SUPER') == 1) {
				$auth_menu = M('auth')->select();
		} else {
			$map['only_super_has'] = 0;
			$auth_menu = M('auth')->where($map)->select();
		}
			//当前访问：控制器/函数名
		$menu_action = CONTROLLER_NAME . '/' . ACTION_NAME;
		$access = 0;
		foreach ($auth_menu as $key => $value) {
			if (($value['controller'] . '/' . $value['function']) == $menu_action) {
					$access = 1;
					break;
			}
		}
		// if ($access == 0) {
		// 	$this->error('您没有访问当前模块权限:' . $menu_action);
		// } else {
		// 		$this->sidebarMenu();
		// }
		$this->sidebarMenu();
	}

	/**
	 * 判断是否有用户登录，没有则跳去登录界面
	 */
	protected function loginOrNot() {
		if (session(C('LOGINNAME')) == null) {
			$this->redirect('Login/index');
		} else {
		}
		// die(print_r(session(C('LOGINNAME'))));
	}

}
?>