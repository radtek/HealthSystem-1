<?php
namespace Home\Controller;
use Think\Controller;

class PlatformManagerController extends CommonController {
	public function index() {
		$this->display();
	}

	public function PlatformManagerTable() {
		$DataTableModel = new \Home\Model\DataTableModel();
		$DataTableModel->data('admin');
	}

	public function edit() {
		$data = $_POST['strJson'];
		$id = $data['id'];
		$newData['username'] = $data['username'];
		$newData['sex'] = $data['sex'];
		$newData['phone'] = $data['phone'];
		$newData['confusion'] = $data['confusion'];
		$newData['loginname'] = $data['loginname'];
		$newData['password'] = md5($data['confusion'] . $data['password']);
		$newData['is_super'] = $data['is_super'];
		$newData['is_active'] = $data['is_active'];
		$result = M('admin')->where("id='$id'")->save($newData);
		if ($result) {
			$data['state'] = 1;
			$data['content'] = 'Modify Success!';
			$this->ajaxReturn($data);
		} else {
			$data['state'] = 0;
			$data['content'] = 'Modify Failed!';
			$this->ajaxReturn($data);
		}
	}

	public function deleteManager() {
		$ids = $_POST;
		$newIds = implode(",", $ids['ids']);
		$adminModel = M('admin');
		$result = $adminModel->delete($newIds);
		if ($result) {
			$data['state'] = 1;
			$data['deleteNum'] = $result;
			$data['content'] = 'Delete Success!';
			$this->ajaxReturn($data);
		} else {
			$data['state'] = 0;
			$data['deleteNum'] = 0;
			$data['content'] = 'Delete Failed!';
			$this->ajaxReturn($data);
		}

	}

	public function addManager() {
		$data = $_POST;
		// $data = json_decode($data);

		if (!empty($data['loginname'])) {
			if ($this->checkManager($data['loginname'])) {
				$this->ajaxReturn(-1); //检测存在
			} else {
				$adminModel = M('admin');
				$data['password'] = md5($data['confusion'] . $data['password']);
				$data['time'] = strtotime(date("Y-m-d H:i:s", time()));
				$result = $adminModel->add($data);
				if ($result) {
					$this->ajaxReturn(1);
				} else {
					$this->ajaxReturn(0);
				}

			}

		}
	}

	public function checkManager($loginname) {
		$DataTableModel = new \Home\Model\DataTableModel();
		$result = $DataTableModel->checkExist('admin', 'loginname', $loginname);
		//返回1说明存在，返回0不存在
		return $result;
	}

}