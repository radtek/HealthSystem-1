<?php
namespace Home\Controller;
use Think\Controller;

class PlottingController extends CommonController {
	public function index() {
		$this->display();
	}

	public function getData(){
		$startTime = (int)$_GET['startTime'];//1460784882;
		$endTime = (int)$_GET['endTime'];//1460784883;
		$user = $_GET['dataUser'];
		$heartModel = M('heart');
		$bloodModel = M('blood_pressure');
		$sleepModel = M('sleep');
		$sportModel = M('sport');
		if(!empty($startTime) && !empty($endTime)){
			$map['time']  = array(array('egt',$startTime),array('elt',$endTime),'and');
		}
		$map['user'] = $user;

		$heartField = 'beat';
		$bloodField = 'systolic_pressure,diastolic_pressure';
		$sleepField = 'sleep_state,turn_over_times';
		$sportField = 'sport_state';

		$heartData = $heartModel->where($map)->field($heartField)->select();
		$bloodData = $bloodModel->where($map)->field($bloodField)->select();
		$sleepData = $sleepModel->where($map)->field($sleepField)->select();
		$sportData = $sportModel->where($map)->field($sportField)->select();

		$heartArr = array();
		$systolicArr = array();
		$diastolicArr = array();
		$turnOverTimesArr = array();
		//heartData
		foreach ($heartData as $key => $value) {
				array_push($heartArr, (int)$value['beat']);
		}
		$bigData['heart'] = $heartArr;
		//bloodData
		foreach ($bloodData as $key => $value) {
				array_push($systolicArr, (int)$value['systolic_pressure']);
				array_push($diastolicArr, (int)$value['diastolic_pressure']);
		}
		$bloodObject['systolic'] = $systolicArr;
		$bloodObject['diastolic'] = $diastolicArr;
		$bigData['blood'] = $bloodObject;

		//sleepData
		$sleepState['lightSleep'] = 0;//浅睡计数
		$sleepState['deepSleep'] = 0;//深睡计数
		$sleepState['awake'] = 0;//醒着计数
		foreach ($sleepData as $key => $value) {
				array_push($turnOverTimesArr, (int)$value['turn_over_times']);
				if($value['sleep_state'] == '深睡'){
					$sleepState['deepSleep']++;
				}else if($value['sleep_state'] == '浅睡'){
					$sleepState['lightSleep']++;
				}else{
					$sleepState['awake']++;
				}
		}
		$sleepObject['sleep_state'] = $sleepState;
		$sleepObject['turn_over_times'] = $turnOverTimesArr;
		$bigData['sleep'] = $sleepObject;

		//sportData
		$sportState['static'] = 0;//静止计数
		$sportState['rest'] = 0;//休息计数
		$sportState['walk'] = 0;//走路计数
		$sportState['run'] = 0;//跑步计数
		foreach ($sportData as $key => $value) {
				if($value['sport_state'] == '静止'){
					$sportState['static']++;
				}else if($value['sport_state'] == '休息'){
					$sportState['rest']++;
				}else if($value['sport_state'] == '走路'){
					$sportState['walk']++;
				}else{
					$sportState['run']++;
				}
		}
		$sportObject['sport_state'] = $sportState;
		$bigData['sport'] = $sportObject;
		// $arrOne =array();
		// $arrTwo = array();
		// if($dataTable == 'heart'){
		// 	foreach ($data as $key => $value) {
		// 		array_push($dataArr, (int)$value['beat']);
		// 		// $dataArr[$key] = $value['beat'];
		// 	}
		// }else if($dataTable == 'blood_pressure'){
		// 	foreach ($data as $key => $value) {
		// 		array_push($arrOne, (int)$value['systolic_pressure']);

		// 		array_push($arrTwo, (int)$value['diastolic_pressure']);
		// 	}
		// 	$objData['systolic_pressure'] = $arrOne;
		// 	$objData['diastolic_pressure'] = $arrTwo;
		// 	array_push($dataArr,$objData);
		// }

		$this->ajaxReturn($bigData);
	}

}