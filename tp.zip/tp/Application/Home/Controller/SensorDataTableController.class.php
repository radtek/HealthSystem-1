<?php
namespace Home\Controller;
use Think\Controller;

class SensorDataTableController extends CommonController {
	public function index() {
		$this->display();
	}

	public function emptyDataTable() {
		$whichTable = $_POST['whichTable'];
		$DataTableModel = new \Home\Model\DataTableModel();
		$data = $DataTableModel->emptyData($whichTable);
		$this->ajaxReturn($data);
	}

	public function usersTable() {
		$DataTableModel = new \Home\Model\DataTableModel();
		$DataTableModel->data('users');;
	}

	public function bloodPressureTable() {
		$DataTableModel = new \Home\Model\DataTableModel();
		$DataTableModel->data('blood_pressure');
	}

	public function heartTable() {
		$DataTableModel = new \Home\Model\DataTableModel();
		$DataTableModel->data('heart');
	}

	public function sleepTable() {
		$DataTableModel = new \Home\Model\DataTableModel();
		$DataTableModel->data('sleep');
	}

	public function sportTable() {
		$DataTableModel = new \Home\Model\DataTableModel();
		$DataTableModel->data('sport');
	}

}