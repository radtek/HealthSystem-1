<?php
namespace Home\Controller;
use Think\Controller;

class IndexController extends CommonController {
	public function index() {
		$this->display();
		// $this->display('fenye1');
	}

	public function fenye() {
		$this->display('fenye1');
	}

	public function tabledemo() {
		$this->display();
	}

	public function initView() {
		$this->display('');
	}

	public function profile() {
		$user = D('admin');
		$map['loginname'] = session('LOGINNAME');
		$result = $user->field('loginname,username,sex,phone')->where($map)->find();
		$this->ajaxReturn($result);
	}

	public function modifyInfor() {
		$username = $_POST['username'];
		$sex = $_POST['sex'];
		$phone = $_POST['phone'];
		$loginname = $_POST['loginname'];
		$newpassword = $_POST['newpassword'];
		$admin = D('admin');
		$mapL['loginname'] = session('LOGINNAME');
		$resultData = $admin->field('id,confusion')->where($mapL)->find();
		if(!empty($username)){
			$map['username'] = $username;
		}
		if(!empty($sex)){
			$map['sex'] = $sex;
		}
		if(!empty($phone)){
			$map['phone'] = $phone;
		}
		if(!empty($loginname)){
			$map['loginname'] = $loginname;
		}
		if(!empty($newpassword)){
			$map['password'] = md5($resultData['confusion'] . $newpassword);
		}
		$id= (int)$resultData['id'];
		$result = $admin->where("id='$id'")->save($map);
		$this->ajaxReturn($result);
	}

	public function mock() {
		$data['name'] = $_GET['data'];
		$obj = D('mock');
		$result = $obj->add($data);
		$this->ajaxReturn($result, 'jsonp');
	}

	public function http_post_data($url, $post_data) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-Type: application/json; charset=utf-8',
			'Content-Length: ' . strlen($data_string))
		);
		/* 普通的post请求更换Content-Type接可以了
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
				'Content-Length: ' . strlen($data_string))
			);
		*/

		curl_exec($ch);

		$return_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		return array($return_code, $return_content);
	}
	public function mytest() {
		// $op = $_POST[a];
		session('myname', '$op');
		return 'nihao';
	}
	public function test() {
		$url = "http://localhost/tp2/Index/mytest";
		// // 将要post的数据直接json格式化就行
		$data = json_encode(array('a' => 16, 'b' => 2));
		// list($return_code, $return_content) = $this->http_post_data($url, $data);
		$this->http_post_data($url, $data);
		session('cond', $return_content);
		// C('MY_NAME','thinkphp_gu');

	}
	public function test2() {
		print_r(session('myname') . '+' . session('cond'));
	}

	public function edit() {
		$result = $_POST['strJson'];
		// $result.='work';
		$data = $this->ajaxReturn($result);
		echo $data;
	}

	public function initTableView() {
		// session('myname',52);
		$limit = $_GET['limit'];
		$offset = $_GET['offset'];
		$humanModel = M('users');
		if ((isset($_GET['search']) && !empty($_GET['search']))) {
			$dbFields = $humanModel->getDbFields();
			$searchWord = trim($_GET['search']);
			// $map['id|firstname|lastname']=$searchWord;
			foreach ($dbFields as $everyField) {
				$condition[$everyField] = $searchWord;
			}
			$condition['_logic'] = 'OR';
			$total = $humanModel->where($condition)->count();
			$rows = $humanModel->where($condition)->limit($offset . ',' . $limit)->select();
			// $total= $humanModel->where($map)->count();
			// $rows = $humanModel->where($map)->limit($offset. ',' .$limit)->select();
		} else {
			$total = $humanModel->count(); // 查询满足要求的总记录数
			if ($limit == 'ALL') {
				$rows = $humanModel->select();
			} else {
				$rows = $humanModel->limit($offset . ',' . $limit)->select();
			}

		}
		// $result = array();
		$result["total"] = $total;
		$result["rows"] = $rows;
		echo json_encode($result);
	}

}