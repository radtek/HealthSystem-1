<?php
namespace Home\Controller;
use Think\Controller;

class GatewayManagerController extends CommonController {
	public function index() {
		$this->display();
	}

	public function emptyDataTable() {
		$whichTable = $_POST['whichTable'];
		$DataTableModel = new \Home\Model\DataTableModel();
		$data = $DataTableModel->emptyData($whichTable);
		$this->ajaxReturn($data);
	}

	public function GatewayManagerTable() {
		$DataTableModel = new \Home\Model\DataTableModel();
		$DataTableModel->data('manager');
	}


}