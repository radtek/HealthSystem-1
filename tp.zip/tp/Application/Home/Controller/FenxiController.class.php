<?php
namespace Home\Controller;
use Think\Controller;

class FenxiController extends Controller {
	public function index() {
		$this->display();
	}

	public function test(){
		$id = $_GET['id'];
		print_r($id);
	}

	public function fenxi() {
		$AnalysisModel = new \Home\Model\AnalysisModel();
		// $result = $AnalysisModel->fenxi('heart','beat','古云');
		$result = $AnalysisModel->weightedAverage('heart','beat','古云');
		$evaluate = $AnalysisModel->heartEvaluate($result);
		echo $result.'---'.$evaluate;
	}
}