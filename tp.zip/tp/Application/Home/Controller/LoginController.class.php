<?php
namespace Home\Controller;
use Think\Controller;

class LoginController extends Controller {
	public function index() {

		$this->display();
	}

	//登录业务，如果登录成功，便在页面上进行跳转
	public function doLogin() {
		$username = $_POST['username'];
		$password = $_POST['password'];
		$verifycode = $_POST['verifycode'];

		if (!empty($username) && !empty($password) && !empty($verifycode)) {
			$loginService = D('Login', 'Service');
			//登录服务
			$result = $loginService->verify($username, $password, $verifycode);

			$this->ajaxReturn($result);
		} else {
			$result['content'] = "用户名/密码/验证码不能为空";
			$this->ajaxReturn($result);
		}
	}

	//产生验证码
	public function verifycode() {
		ob_clean();
		$verify = new \Think\Verify();
		$verify->codeSet = '0123456789';
		$verify->fontSize = '20px';
		$verify->imageW = 160;
		$verify->imageH = 38;
		$verify->length = 4;
		$verify->useCurve = true;
		$verify->useNoise = true;
		$verify->entry();
	}

	//退出登录
	public function exitLogin() {
		$loginService = D('Login', 'Service');
		$result = $loginService->exitLogin();
		// var_dump($result);die;
		if ($result['status'] === false) {
			$this->error($result['data']['error'], U('Login/index'));
		} else {
			$this->success($result['data']['success'], U('Login/index'));
		}
	}
}