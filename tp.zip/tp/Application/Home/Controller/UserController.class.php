<?php
namespace Home\Controller;
use Think\Controller;

class UserController extends CommonController {
	public function index() {
		$this->display();
	}

	public function emptyDataTable() {
		$whichTable = $_POST['whichTable'];
		// $data['state'] = 1;
		// $data['deleteNum'] = 50;
		// $data['content'] = 'Success!';
		// $this->ajaxReturn($data);
		$SensorDataTableModel = new \Home\Model\SensorDataTableModel();
		$data = $SensorDataTableModel->emptyData($whichTable);
		$this->ajaxReturn($data);
	}

	public function showUserName() {
		$limit = $_GET['limit'];
		$offset = $_GET['offset'];
		$objModel = M('heart');
		if ((isset($_GET['search']) && !empty($_GET['search']))) {
			$searchWord = trim($_GET['search']);
			$map['user'] = $searchWord;
			$total = $objModel->where($map)->count('DISTINCT user');
			$rows = $objModel->distinct(true)->where($map)->field('user')->select();
		} else {
			$total = $objModel->count('DISTINCT user'); // 查询满足要求的总记录数
			if ($limit == 'ALL') {
				$rows = $objModel->distinct(true)->field('user')->select();
			} else {
				$rows = $objModel->distinct(true)->field('user')->limit($offset . ',' . $limit)->select();
			}

		}

		$result["total"] = $total;
		$result["rows"] = $rows;
		echo json_encode($result);
	}

}