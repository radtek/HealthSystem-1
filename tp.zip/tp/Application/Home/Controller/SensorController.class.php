<?php
namespace Home\Controller;
use Think\Controller;

class SensorController extends Controller {
//deleteAll   addAll可以尝试使用
	public function index() {
		$this->display();
		// $this->display('fenye1');
	}

	public function mockuser() {
		// $data['mockdata'] = $_GET;

		$data['username'] = $_GET['username'];
		$data['sex'] = $_GET['sex'];
		$data['age'] = $_GET['age'];
		$data['phone'] = $_GET['phone'];
		$data['address'] = $_GET['address'];
		$data['doctor'] = $_GET['doctor'];
		$obj = D('user');
		$result = $obj->add($data);
		// $this->ajaxReturn($result, 'jsonp');

		$backdata[result] = $result;
		$backdata[data] = $data;
		$this->ajaxReturn($backdata, 'jsonp');
	}

	public function receiveManagerData() {
		$dataObjArr = $_GET['dataObjArr'];
		foreach ($dataObjArr as $key => $value) {
			$newDataArr[$key] = $value;
			$data['id_from_post'] = $newDataArr[$key]['id'];
			$data['username'] = $newDataArr[$key]['username'];
			$data['loginname'] = $newDataArr[$key]['user'];
			$data['password'] = $newDataArr[$key]['password'];
			$data['userimg'] = $newDataArr[$key]['userimg'];
			$data['is_super'] = $newDataArr[$key]['is_super'];
			$data['time'] = (int)$newDataArr[$key]['add_time'];

			$isWriteManager = $this->writeManagerData($data);
			$everyRowBackData['id_from_post'] = $newDataArr[$key]['id'];
			$everyRowBackData['actionInfor'] = $isWriteManager;

			$allBackData[$key] = $everyRowBackData;

		}
		$this->ajaxReturn($allBackData, 'jsonp');
	}

	public function receiveUserData() {
		$dataObjArr = $_GET['dataObjArr'];
		foreach ($dataObjArr as $key => $value) {
			$newDataArr[$key] = $value;
			$data['id'] = $newDataArr[$key]['id'];
			// $data['id_from_post'] = $newDataArr[$key]['id'];
			$data['username'] = $newDataArr[$key]['username'];
			$data['sex'] = $newDataArr[$key]['sex'];
			$data['age'] = $newDataArr[$key]['age'];
			$data['phone'] = $newDataArr[$key]['phone'];
			$data['address'] = $newDataArr[$key]['address'];
			$data['information'] = $newDataArr[$key]['information'];
			$data['doctor'] = $newDataArr[$key]['doctor'];
			$data['time'] = $newDataArr[$key]['add_time'];

			$isWriteUser = $this->writeUserData($data);
			$everyRowBackData['id_from_post'] = $newDataArr[$key]['id'];
			$everyRowBackData['actionInfor'] = $isWriteUser;

			$allBackData[$key] = $everyRowBackData;

		}
		$this->ajaxReturn($allBackData, 'jsonp');
	}
//{ "id": "1", "user": "小明", "systolic": "110", "diastolic": "73", "beat": "75", "sleep": "深睡", "turn_over_times": "1", "sport": "休息", "add_time": "1459696263" }
	public function receiveSensorData() {
		$dataObjArr = $_GET['dataObjArr'];
		foreach ($dataObjArr as $key => $value) {
			$newDataArr[$key] = $value;
			$data['id_from_post'] = $newDataArr[$key]['id'];
			$data['user'] = $newDataArr[$key]['user'];
			$data['systolic'] = $newDataArr[$key]['systolic'];
			$data['diastolic'] = $newDataArr[$key]['diastolic'];
			$data['beat'] = $newDataArr[$key]['beat'];
			$data['sleep'] = $newDataArr[$key]['sleep'];
			$data['turn_over_times'] = $newDataArr[$key]['turn_over_times'];
			$data['sport'] = $newDataArr[$key]['sport'];
			$data['add_time'] = $newDataArr[$key]['add_time'];

			$isWriteBlood = $this->writeBloodPressureData($data);
			$isWriteHeart = $this->writeHeartData($data);
			$isWriteSleep = $this->writeSleepData($data);
			$isWriteSport = $this->writeSportData($data);

			$everyRowBackData['id_from_post'] = $newDataArr[$key]['id'];
			$everyRowBackData['actionInfor'] = $this->isWriteSensorSucess($isWriteBlood, $isWriteHeart, $isWriteSleep, $isWriteSport);

			$allBackData[$key] = $everyRowBackData;

		}
		$this->ajaxReturn($allBackData, 'jsonp');
	}

	public function isWriteSensorSucess($isWriteBlood, $isWriteHeart, $isWriteSleep, $isWriteSport) {
		if ($isWriteBlood) {
			$backdata['isWriteBloodSuccess'] = 'Write Blood Data Success';
		} else {
			$backdata['isWriteBloodSuccess'] = 'Write Blood Data Failed';
		}
		if ($isWriteHeart) {
			$backdata['isWriteHeartSuccess'] = 'Write Heart Data Success';
		} else {
			$backdata['isWriteHeartSuccess'] = 'Write Heart Data Failed';
		}
		if ($isWriteSleep) {
			$backdata['isWriteSleepSuccess'] = 'Write Sleep Data Success';
		} else {
			$backdata['isWriteSleepSuccess'] = 'Write Sleep Data Failed';
		}
		if ($isWriteSport) {
			$backdata['isWriteSportSuccess'] = 'Write Sport Data Success';
		} else {
			$backdata['isWriteSportSuccess'] = 'Write Sport Data Failed';
		}
		return $backdata;
	}

	public function writeUserData($data) {
		$user = D('user');
		$userResult = $user->add($data);
		if ($userResult) {
			return 'Write User Data Success';
		} else {
			return 'Write User Data Failed';
		}
	}
	public function writeManagerData($data) {
		$manager = D('manager');
		$managerResult = $manager->add($data);
		if ($managerResult) {
			return 'Write Manager Data Success';
		} else {
			return 'Write Manager Data Failed';
		}
	}

	public function writeSportData($data) {
		$sportData['user'] = $data['user'];
		$sportData['sport_state'] = $data['sport'];
		$sportData['time'] = $data['add_time'];

		$sport = D('sport');
		$sportResult = $sport->add($sportData);
		if ($sportResult) {
			return 1;
		} else {
			return 0;
		}
	}
	public function writeSleepData($data) {
		$sleepData['user'] = $data['user'];
		$sleepData['sleep_state'] = $data['sleep'];
		$sleepData['turn_over_times'] = $data['turn_over_times'];
		$sleepData['time'] = $data['add_time'];

		$sleep = D('sleep');
		$sleepResult = $sleep->add($sleepData);
		if ($sleepResult) {
			return 1;
		} else {
			return 0;
		}
	}
	public function writeHeartData($data) {
		$heartData['user'] = $data['user'];
		$heartData['beat'] = $data['beat'];
		$heartData['time'] = $data['add_time'];

		$heart = D('heart');
		$heartResult = $heart->add($heartData);
		if ($heartResult) {
			return 1;
		} else {
			return 0;
		}
	}
	public function writeBloodPressureData($data) {
		$BloodPressureData['user'] = $data['user'];
		$BloodPressureData['systolic_pressure'] = $data['systolic'];
		$BloodPressureData['diastolic_pressure'] = $data['diastolic'];
		$BloodPressureData['time'] = $data['add_time'];

		$blood = D('blood_pressure');
		$bloodResult = $blood->add($BloodPressureData);
		if ($bloodResult) {
			return 1;
		} else {
			return 0;
		}

	}

}