<?php
namespace Home\Controller;
use Think\Controller;

class WechatController extends Controller {

	public function index() {
		$nonce = $_GET['nonce'];
		$token = 'weixin';
		$timestamp = $_GET['timestamp'];
		$echostr = $_GET['echostr'];
		$signature = $_GET['signature'];
		//形成数组，然后按字典序排序
		$array = array();
		$array = array($nonce, $timestamp, $token);
		sort($array);
		//拼接成字符串,sha1加密 ，然后与signature进行校验
		$str = sha1(implode($array));
		if ($str == $signature && $echostr) {
			//第一次接入weixin api接口的时候
			echo $echostr;
			exit;
		} else {
			$this->reponseMsg();
		}
	}
	// 接收事件推送并回复
	public function reponseMsg() {
		//1.获取到微信推送过来post数据（xml格式）
		$postArr = $GLOBALS['HTTP_RAW_POST_DATA'];
		//2.处理消息类型，并设置回复类型和内容
		/*<xml>
		<wechatIdName><![CDATA[wechatId]]></wechatIdName>
		<FromUserName><![CDATA[FromUser]]></FromUserName>
		<CreateTime>123456789</CreateTime>
		<MsgType><![CDATA[event]]></MsgType>
		<Event><![CDATA[subscribe]]></Event>
		</xml>*/
		$postObj = simplexml_load_string($postArr);
		switch (strtolower($postObj->MsgType)) {
		case "event":
			$result = $this->receiveEvent($postObj);
			break;
		case "text":
			$result = $this->receiveText($postObj);
			break;
		case "image":
			$result = $this->receiveImage($postObj);
			break;
		case "location":
			$result = $this->receiveLocation($postObj);
			break;
		case "voice":
			$result = $this->receiveVoice($postObj);
			break;
		case "video":
			$result = $this->receiveVideo($postObj);
			break;
		case "link":
			$result = $this->receiveLink($postObj);
			break;
		default:
			$result = "unknown msg type: " . $postObj->MsgType;
			break;
		}
	}

	public function receiveEvent($postObj) {
		$wechatId = trim($postObj->FromUserName);
		$WechatModel = new \Home\Model\WechatModel();
		$AnalysisModel = new \Home\Model\AnalysisModel();
		$wechat = M('wechat');
		switch ($postObj->Event) {
		case "subscribe":
			$content = "欢迎关注我们的云端服务平台微信公众号\n请输入姓名:\n绑定账号";
			break;
		case "unsubscribe":
			$content = "取消关注";
			break;
		case "CLICK":
			switch ($postObj->EventKey) {
			case "heart":
				$map['wechat_id'] = $wechatId;
				$row = $wechat->where($map)->find();
				$result = $AnalysisModel->weightedAverage('heart','beat',$row['username']);
				$evaluate = $AnalysisModel->heartEvaluate($result);
				$content = '近期心跳:'.$result."\n".$evaluate;
				break;
			case "blood":
				$content = '血压分析模块..';
				break;
			case "sleep":
				$content = '睡眠分析模块..';
				break;
			case "sport":
				$content = '运动分析模块..';
				break;
			case "heartChart":
				$url = 'Phone/index/id/'.$wechatId;
				$huashengke = 'http://sayzhbit.oicp.net';
				$content = $huashengke.U($url);
				break;
			case "bloodChart":
				$content = '血压图模块..';
				break;
			case "sleepChart":
				$content = '睡眠图模块..';
				break;
			case "sportChart":
				$content = '运动图模块..';
				break;
			case "unbind":
				$content = $WechatModel->unbindWechatId($wechatId);
				break;
			case "our":
				$content = "云计算架构下的医疗健康服务原型系统--云端服务平台\n版权归zhbit所有";
				break;
			default:
				$content = '点击菜单:' . $postObj->EventKey;
				break;
			}
			break;
		case "VIEW":
			$content = '跳转链接' . $postObj->EventKey;
			break;
		default:
			$content = "receive a new event: " . $postObj->Event;
			break;
		}
		if (is_array($content)) {
			if (isset($content[0]['picUrl'])) {
				$WechatModel->responseNews($postObj, $content);
			} else if (isset($content['MusicUrl'])) {
				$WechatModel->transmitMusic($postObj, $content);
			}
		} else {
			$WechatModel->responseText($postObj, $content);
		}

	}
	public function receiveText($postObj) {
		$WechatModel = new \Home\Model\WechatModel();
		$data = array();
		$wechatId = $postObj->FromUserName;
		// $fromUser = $postObj->wechatIdName;

		$username = $postObj->Content;
		$result = $WechatModel->bandNameAndWechatId($username,$wechatId);
		$WechatModel->responseText($postObj, $result);
	}

}