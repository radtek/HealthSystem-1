$(function() {
	var startDateTextBox = $('#range_example_1_start')
	var endDateTextBox = $('#range_example_1_end')

	startDateTextBox.datetimepicker({
		timeFormat: 'hh:mm:ss',
		// timeFormat: 'HH:mm z',
		onClose: function(dateText, inst) {
			if (endDateTextBox.val() != '') {
				var testStartDate = startDateTextBox.datetimepicker('getDate')
				var testEndDate = endDateTextBox.datetimepicker('getDate')
				if (testStartDate > testEndDate)
					endDateTextBox.datetimepicker('setDate', testStartDate)
			} else {
				endDateTextBox.val(dateText)
			}
			console.log('start:' + startDateTextBox.datetimepicker('getDate').getTime().toString().substr(0, 10))
		},
		onSelect: function(selectedDateTime) {
			endDateTextBox.datetimepicker('option', 'minDate', startDateTextBox.datetimepicker('getDate'))

		}
	})
	endDateTextBox.datetimepicker({
		// timeFormat: 'HH:mm z',
		timeFormat: 'hh:mm:ss',
		onClose: function(dateText, inst) {
			if (startDateTextBox.val() != '') {
				var testStartDate = startDateTextBox.datetimepicker('getDate')
				var testEndDate = endDateTextBox.datetimepicker('getDate')
				if (testStartDate > testEndDate)
					startDateTextBox.datetimepicker('setDate', testEndDate)
			} else {
				startDateTextBox.val(dateText)
			}
			console.log('end:' + endDateTextBox.datetimepicker('getDate').getTime().toString().substr(0, 10))
		},
		onSelect: function(selectedDateTime) {
			startDateTextBox.datetimepicker('option', 'maxDate', endDateTextBox.datetimepicker('getDate'))
		}
	})
})