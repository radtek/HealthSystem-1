<?php

  $appid        = "wx4af520e47ca0d446";
  $appsecret    = "f6e991c48c06d18615d4db43e7628876";
  $url          = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
  $output       = https_request($url);
  $jsoninfo     = json_decode($output, true);
  $access_token = $jsoninfo["access_token"];

  $jsonmenu = '{
      "button":[
         {
           "name":"健康分析",
           "sub_button":[
            {
               "type":"click",
               "name":"心跳",
               "key":"heart"
            },
            {
               "type":"click",
               "name":"血压",
               "key":"blood"
            },
            {
               "type":"click",
               "name":"睡眠",
               "key":"sleep"
            },
            {
               "type":"click",
               "name":"运动",
               "key":"sport"
            }]
         },
         {
           "name":"健康图表",
           "sub_button":[
            {
               "type":"click",
               "name":"心跳图",
               "key":"heartChart"
            },
            {
               "type":"click",
               "name":"血压图",
               "key":"bloodChart"
            },
            {
               "type":"click",
               "name":"睡眠图",
               "key":"sleepChart"
            },
            {
               "type":"click",
               "name":"运动图",
               "key":"sportChart"
            }]
          },
          {
            "name":"工作室",
            "sub_button":[
              {
                "type":"click",
                "name":"解除绑定",
                "key":"unbind"
              },
              {
                 "type":"click",
                 "name":"关于我们",
                 "key":"our"
              }]
        }]
   }';


  $url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$access_token;
  $result = https_request($url, $jsonmenu);
  var_dump($result);

  function https_request($url,$data = null){
      $curl = curl_init();
      curl_setopt($curl, CURLOPT_URL, $url);
      curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
      curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
      if (!empty($data)){
          curl_setopt($curl, CURLOPT_POST, 1);
          curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
      }
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
      $output = curl_exec($curl);
      curl_close($curl);
      return $output;
 }

?>